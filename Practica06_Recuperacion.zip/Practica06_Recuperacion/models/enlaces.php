<?php 

class Paginas{
	
	public function enlacesPaginasModel($enlaces){


		if( $enlaces == "maestros" || 
			$enlaces == "alumnos"  ||
			$enlaces == "editarAlumno" ||
			$enlaces == "editarMaestro" ||
			$enlaces == "registrarAlumno" ||
			$enlaces == "registrarMaestro"){

			$module =  "views/modules/".$enlaces.".php";
		
		} else{

			$module =  "views/modules/maestros.php";

		}
		
		return $module;

	}

}

?>