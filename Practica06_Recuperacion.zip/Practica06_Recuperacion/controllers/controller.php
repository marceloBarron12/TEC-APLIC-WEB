<?php

class MvcController{

	#LLAMADA A LA PLANTILLA
	#-------------------------------------

	public function pagina(){	
		
		include "views/template.php";
	
	}

	#ENLACES
	#-------------------------------------

	public function enlacesPaginasController(){

		if(isset( $_GET['action'])){
			
			$enlaces = $_GET['action'];
		
		}

		else{

			$enlaces = "index";
		}

		$respuesta = Paginas::enlacesPaginasModel($enlaces);

		include $respuesta;

	}

	public function registroMaestroController(){

		if(isset($_POST["nombreMaestro"])){

			$datosController = array( "nombre"=>$_POST["nombreMaestro"], 
								      "apellido"=>$_POST["apellidoMaestro"],
								      "correo"=>$_POST["correoMaestro"],
								  	  "carrera"=>$_POST["carreraMaestro"]);

			$respuesta = Datos::registroMaestroModel($datosController, "maestros");

			if($respuesta == "success"){

				//header("location:index.php?action=ok");

				$URL="index.php?action=maestros";
				echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
				echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';

			}

			else{

				header("location:index.php");
			}

		}

	}




	public function vistaMestrosController(){

		$respuesta = Datos::vistaMaestrosModel("maestros");

		#El constructor foreach proporciona un modo sencillo de iterar sobre arrays. foreach funciona sólo sobre arrays y objetos, y emitirá un error al intentar usarlo con una variable de un tipo diferente de datos o una variable no inicializada.

		foreach($respuesta as $row => $item){
		echo'<tr>
				<td>'.$item["noEmpleado"].'</td>
				<td>'.$item["nombre"].'</td>
				<td>'.$item["apellido"].'</td>
				<td>'.$item["email"].'</td>
				<td>'.$item["carrera"].'</td>
				<td><a href="index.php?action=editarMaestro&id='.$item["noEmpleado"].'" type="button" class="btn btn-warning waves-effect waves-light"> Editar </a></td>
				<td><a href="index.php?action=maestros&idBorrar='.$item["noEmpleado"].'" type="button" class="btn btn-danger waves-effect waves-light" > Borrar </a></td>
			</tr>';



		}

	}


	public function editarMaestroController(){

		$datosController = $_GET["id"];
		$respuesta = Datos::editarMaestroModel($datosController, "maestros");

		echo'<div class="form-group"> <input class="form-control" type="hidden" value="'.$respuesta["noEmpleado"].'" name="noEmpleado"></div>

			 <div class="form-group"><input class="form-control" type="text" value="'.$respuesta["nombre"].'" name="nombreMaestro" required></div>

			 <div class="form-group"><input class="form-control" type="text" value="'.$respuesta["apellido"].'" name="apellidoMaestro" required></div>

			 <div class="form-group"><input class="form-control" type="text" value="'.$respuesta["email"].'" name="correoMaestro" required></div>

			 <div class="form-group margin-bottom-20">
			 				<label >Carrera:</label>
							<select name="carreraMaestro" class="form-control">

								<option value="ITI" >
								 	ITI 
							 	</option>

							 	<option value="PYMES" >
								 	PYMES 
							 	</option>

							 	<option value="ISA" >
								 	ISA 
							 	</option>

							 	<option value="MANUFACTURA" >
								 	MANUFACTURA 
							 	</option>

							 	<option value="MECATRONICA" >
								 	MECATRONICA 
							 	</option>

							</select>
						</div>

			 <div class="form-group"><input class="btn btn-warning btn-sm waves-effect waves-light" type="submit" value="Actualizar"> </div>' ;	


	}


	public function actualizarMaestroController(){

		if(isset($_POST["nombreMaestro"])){

			$datosController = array( "nombre"=>$_POST["nombreMaestro"],
							          "apellido"=>$_POST["apellidoMaestro"],
				                      "correo"=>$_POST["correoMaestro"],
				                      "carrera"=>$_POST["carreraMaestro"],
			                  		  "id" => $_POST["noEmpleado"]);
			
			$respuesta = Datos::actualizarMaestroModel($datosController, "maestros");

			if($respuesta == "success"){

				$URL="index.php?action=maestros";
				echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
				echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';

			}

			else{

				echo "error";

			}

		}
	
	}


	public function borrarMaestroController(){

		if(isset($_GET["idBorrar"])){

			$datosController = $_GET["idBorrar"];
			
			$respuesta = Datos::borrarMaestroModel($datosController, "maestros");

			if($respuesta == "success"){
				$URL="index.php?action=maestros";
				echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
				echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
			
			}

		}

	}







	public function registroAlumnoController(){

		if(isset($_POST["matriculaAlumno"])){

			$datosController = array( "matricula"=>$_POST["matriculaAlumno"], 
								      "nombre"=>$_POST["nombreAlumno"],
								      "apellidos"=>$_POST["apellidosAlumno"],
								  	  "correo"=>$_POST["correoAlumno"],
								  	  "carrera"=>$_POST["carreraAlumno"]);

			$respuesta = Datos::registroAlumnoModel($datosController, "alumnos");

			if($respuesta == "success"){

				//header("location:index.php?action=ok");

				$URL="index.php?action=alumnos";
				echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
				echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';

			}

			else{

				header("location:index.php?action=alumnos");
			}

		}

	}



	public function vistaAlumnosController(){

		$respuesta = Datos::vistaAlumnosModel("alumnos");

		#El constructor foreach proporciona un modo sencillo de iterar sobre arrays. foreach funciona sólo sobre arrays y objetos, y emitirá un error al intentar usarlo con una variable de un tipo diferente de datos o una variable no inicializada.

		foreach($respuesta as $row => $item){
		echo'<tr>
				<td>'.$item["matricula"].'</td>
				<td>'.$item["nombre"].'</td>
				<td>'.$item["apellidos"].'</td>
				<td>'.$item["email"].'</td>
				<td>'.$item["carrera"].'</td>
				<td><a href="index.php?action=editarAlumno&id='.$item["matricula"].'" type="button" class="btn btn-warning waves-effect waves-light"> Editar </a></td>
				<td><a href="index.php?action=alumnos&idBorrar='.$item["matricula"].'" type="button" class="btn btn-danger waves-effect waves-light" > Borrar </a></td>
			</tr>';



		}

	}



	public function editarAlumnoController(){

		$datosController = $_GET["id"];
		$respuesta = Datos::editarAlumnoModel($datosController, "alumnos");

		echo'<div class="form-group"> 

			<input class="form-control" type="hidden" value="'.$respuesta["matricula"].'" name="matriculaAlumno"></div>

			 <div class="form-group">
			 <label >Nombre:</label>
			 <input class="form-control" type="text" value="'.$respuesta["nombre"].'" name="nombreAlumno" required></div>

			 <div class="form-group">
			 <label >Apellidos:</label>
			 <input class="form-control" type="text" value="'.$respuesta["apellidos"].'" name="apellidosAlumno" required></div>

			 <div class="form-group">
			 <label >Correo:</label>
			 <input  class="form-control" type="email" value="'.$respuesta["email"].'" name="correoAlumno" required></div>


			 <div class="form-group margin-bottom-20">
			 				<label >Carrera:</label>
							<select name="carreraAlumno" class="form-control">

								<option value="ITI" >
								 	ITI 
							 	</option>

							 	<option value="PYMES" >
								 	PYMES 
							 	</option>

							 	<option value="ISA" >
								 	ISA 
							 	</option>

							 	<option value="MANUFACTURA" >
								 	MANUFACTURA 
							 	</option>

							 	<option value="MECATRONICA" >
								 	MECATRONICA 
							 	</option>

							</select>
						</div>

			 <div class="form-group"><input class="btn btn-warning btn-sm waves-effect waves-light" type="submit" value="Actualizar"> </div>' ;	 

	}


	public function actualizarAlumnoController(){

		if(isset($_POST["nombreAlumno"])){

			$datosController = array( "matricula"=>$_POST["matriculaAlumno"],
							          "nombre"=>$_POST["nombreAlumno"],
				                      "apellidos"=>$_POST["apellidosAlumno"],
				                      "correo"=>$_POST["correoAlumno"],
				                  	  "carrera"=>$_POST["carreraAlumno"]);
			
			$respuesta = Datos::actualizarAlumnoModel($datosController, "alumnos");

			if($respuesta == "success"){

				$URL="index.php?action=alumnos";
				echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
				echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';

			}

			else{

				echo "error";

			}

		}
	
	}

	public function borrarAlumnoController(){

		if(isset($_GET["idBorrar"])){

			$datosController = $_GET["idBorrar"];
			
			$respuesta = Datos::borrarAlumnoModel($datosController, "alumnos");

			if($respuesta == "success"){
				$URL="index.php?action=alumnos";
				echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
				echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
			
			}

		}

	}

	



	

}

?>