<?php

#Registro de usuarios, ventas, productos
#Folios de ventas, detalles de ventas
#Los detalles de venta en cada producto vendido


require_once "models/enlaces.php";
require_once "models/crud.php";
require_once "controllers/controller.php";

$mvc = new MvcController();
$mvc -> pagina();

?>